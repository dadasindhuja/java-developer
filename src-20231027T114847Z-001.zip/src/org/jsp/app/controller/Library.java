package org.jsp.app.controller;

import org.jsp.app.controller.utility.Librarian;

public class Library {
	public static void main(String[] args) {
		Librarian librarian = new Librarian();
		librarian.start();
	}
}

		